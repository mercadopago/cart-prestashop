<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mercadopago}prestashop>standard_e2b7dec8fa4b498156dfee6e4c84b156'] = 'O meio de pagamento não esta disponível.';
$_MODULE['<{mercadopago}prestashop>standard_0944f2288451f269e5bad1f703219647'] = 'Mercado Pago Redirecionado';
$_MODULE['<{mercadopago}prestashop>paymentconfiguration_93052020a3b86afb91cfdf049c4ea0dd'] = 'Texto personalizado para ser utilizado na entrega';
$_MODULE['<{mercadopago}prestashop>paymentconfiguration_4c61bbfb5611b5899b98efe3b70196af'] = 'Ex: O produto vai ser entregue entre 2 a 8 dias.';
$_MODULE['<{mercadopago}prestashop>paymentconfiguration_243ca9f80cb8ae29d16ea121bbc7cde3'] = 'Habilitar Mercado Envios';
$_MODULE['<{mercadopago}prestashop>paymentconfiguration_fedf9a1e5e73028956e2458afdf7337c'] = 'Utilize o Mercado Envios para suas entregas com pagamentos com Mercado Pago';
$_MODULE['<{mercadopago}prestashop>paymentconfiguration_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar Configuração';
$_MODULE['<{mercadopago}prestashop>displaystatusorderticket_46eb7527bd092cad9d295e5c35a6be0c'] = 'Obrigado, seu pagamento foi aprovado.';
$_MODULE['<{mercadopago}prestashop>displaystatusorderticket_954eff650d90fb9c3ab18a381ada43bf'] = 'Obrigado, estamos aguardando seu pagamento.';
$_MODULE['<{mercadopago}prestashop>displaystatusorderticket_0d74380b0947b0f997af5b9d780e102d'] = 'Infelizmente seu pagamento foi recusado.';
